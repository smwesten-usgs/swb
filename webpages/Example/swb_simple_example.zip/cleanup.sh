#!/bin/sh
rm -f output/annual/*.*
rm -f output/monthly/*.*
rm -f output/daily/*.*
rm -f output/*.*
rm -f images/annual/*.*
rm -f images/monthly/*.*
rm -f images/daily/*.*
rm -f images/*.*
rm -f output/*.bin
